/*
 * Copyright (C) 2023 Dominik Drexler and Simon Stahlberg
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef MIMIR_SEARCH_ALGORITHMS_BRFS_EVENT_HANDLERS_INTERFACE_HPP_
#define MIMIR_SEARCH_ALGORITHMS_BRFS_EVENT_HANDLERS_INTERFACE_HPP_

#include "mimir/formalism/declarations.hpp"
#include "mimir/search/algorithms/brfs/event_handlers/statistics.hpp"
#include "mimir/search/declarations.hpp"

#include <chrono>
#include <cstddef>
#include <concepts>
#include <cstdint>

namespace mimir::search::brfs
{

/**
 * Interface class
 */
class IEventHandler
{
public:
    virtual ~IEventHandler() = default;

    /// @brief React on expanding a state. This is called immediately after popping from the queue.
    virtual void on_expand_state(const State& state) = 0;

    /// @brief React on expanding a goal `state`. This may be called after on_expand_state.
    virtual void on_expand_goal_state(const State& state) = 0;

    /// @brief React on generating a state by applying an action.
    virtual void on_generate_state(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) = 0;
    virtual bool supports_novel_witness_events() const { return false; }
    virtual void on_generate_state_with_novel_witness(const State& state,
                                                       formalism::GroundAction action,
                                                       ContinuousCost action_cost,
                                                       const State& successor_state,
                                                       const iw::AtomIndexList& novel_fluent_atom_indices)
    {
    }

    /// @brief Lightweight generated-state hook for quiet handlers in the staged beam fast path.
    virtual bool supports_payloadless_generated_state_events() const { return false; }
    virtual void on_generate_state_without_payload() {}
    virtual void on_generate_state_in_search_tree_without_payload() {}
    virtual void on_generate_state_not_in_search_tree_without_payload() {}

    /// @brief React on generating a state in the search tree by applying an action.
    virtual void
    on_generate_state_in_search_tree(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) = 0;

    /// @brief React on generating a state not in the search tree by applying an action.
    virtual void
    on_generate_state_not_in_search_tree(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) = 0;

    /// @brief React on finishing expanding a g-layer.
    virtual void on_finish_g_layer(DiscreteCost g_value) = 0;

    /// @brief React on starting a search.
    virtual void on_start_search(const State& start_state) = 0;

    /// @brief React on ending a search.
    virtual void on_end_search(uint64_t num_reached_fluent_atoms,
                               uint64_t num_reached_derived_atoms,
                               uint64_t num_states,
                               uint64_t num_nodes,
                               uint64_t num_actions,
                               uint64_t num_axioms) = 0;

    virtual void on_finish_iw1_incremental_first_applicability(
        const IW1IncrementalFirstApplicabilityStatistics& iw1_incremental_first_applicability_statistics)
    {
    }

    /// @brief React on finishing one parallel beam chunk.
    virtual void on_finish_parallel_beam_chunk(size_t chunk_size,
                                               std::chrono::nanoseconds worker_compute_time,
                                               std::chrono::nanoseconds main_thread_merge_time,
                                               std::chrono::nanoseconds main_thread_intern_time,
                                               std::chrono::nanoseconds fluent_slot_time,
                                               std::chrono::nanoseconds numeric_slot_time,
                                               std::chrono::nanoseconds derived_slot_time,
                                               std::chrono::nanoseconds state_lookup_time,
                                               std::chrono::nanoseconds reached_atom_update_time)
    {
    }

    /// @brief React on finishing the parallel beam pipeline for one search.
    virtual void on_finish_parallel_beam_pipeline(size_t ready_queue_high_water,
                                                  size_t in_flight_chunks_high_water,
                                                  std::chrono::nanoseconds consumer_stall_time,
                                                  std::chrono::nanoseconds producer_stall_time)
    {
    }

    /// @brief React on solving a search.
    virtual void on_solved(const Plan& plan) = 0;

    /// @brief React on proving unsolvability during a search.
    virtual void on_unsolvable() = 0;

    /// @brief React on exhausting a search.
    virtual void on_exhausted() = 0;

    virtual const Statistics& get_statistics() const = 0;
};

/**
 * Base class
 *
 * Collect statistics and call implementation of derived class.
 */
template<typename Derived_>
class EventHandlerBase : public IEventHandler
{
protected:
    Statistics m_statistics;
    formalism::Problem m_problem;
    bool m_quiet;

private:
    EventHandlerBase() = default;
    friend Derived_;

    /// @brief Helper to cast to Derived.
    constexpr const auto& self() const { return static_cast<const Derived_&>(*this); }
    constexpr auto& self() { return static_cast<Derived_&>(*this); }

public:
    explicit EventHandlerBase(formalism::Problem problem, bool quiet = true) : m_statistics(), m_problem(problem), m_quiet(quiet) {}

    void on_expand_state(const State& state) override
    {
        m_statistics.increment_num_expanded();

        if (!m_quiet)
        {
            self().on_expand_state_impl(state);
        }
    }

    void on_expand_goal_state(const State& state) override
    {
        m_statistics.increment_num_expanded_goal_states();

        if (!m_quiet)
        {
            self().on_expand_goal_state_impl(state);
        }
    }

    void on_generate_state(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) override
    {
        m_statistics.increment_num_generated();

        if (!m_quiet)
        {
            self().on_generate_state_impl(state, action, action_cost, successor_state);
        }
    }

    /* Computing a novelty witness costs a scan of the transition's novel atoms, so a search only
       pays for it when a handler says it consumes the witness. That is a capability of the concrete
       handler, not of its verbosity: a non-quiet handler that never reads witnesses (this base's own
       `on_generate_state_with_novel_witness` ignores them) would otherwise make every search compute
       them for nothing, and a handler that does want them while staying quiet could not ask. Derived
       handlers that implement `on_generate_state_with_novel_witness` override this to return true. */
    bool supports_novel_witness_events() const override { return false; }

    void on_generate_state_with_novel_witness(const State& state,
                                              formalism::GroundAction action,
                                              ContinuousCost action_cost,
                                              const State& successor_state,
                                              const iw::AtomIndexList& novel_fluent_atom_indices) override
    {
        [[maybe_unused]] const auto& ignored_state = state;
        [[maybe_unused]] const auto ignored_action = action;
        [[maybe_unused]] const auto ignored_action_cost = action_cost;
        [[maybe_unused]] const auto& ignored_successor_state = successor_state;
        [[maybe_unused]] const auto& ignored_novel_fluent_atom_indices = novel_fluent_atom_indices;
    }

    bool supports_payloadless_generated_state_events() const override { return m_quiet; }

    /* The payloadless hooks feed exactly the same counters as their payloadful counterparts, so a
       search that reports a transition without payload is indistinguishable in the statistics from
       one that reports it with payload. */
    void on_generate_state_without_payload() override { m_statistics.increment_num_generated(); }

    void on_generate_state_in_search_tree_without_payload() override { m_statistics.increment_num_generated_in_search_tree(); }

    void on_generate_state_not_in_search_tree_without_payload() override { m_statistics.increment_num_generated_not_in_search_tree(); }

    void on_generate_state_in_search_tree(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) override
    {
        m_statistics.increment_num_generated_in_search_tree();

        if (!m_quiet)
        {
            self().on_generate_state_in_search_tree_impl(state, action, action_cost, successor_state);
        }
    }

    void
    on_generate_state_not_in_search_tree(const State& state, formalism::GroundAction action, ContinuousCost action_cost, const State& successor_state) override
    {
        m_statistics.increment_num_generated_not_in_search_tree();

        if (!m_quiet)
        {
            self().on_generate_state_not_in_search_tree_impl(state, action, action_cost, successor_state);
        }
    }

    void on_finish_g_layer(DiscreteCost g_value) override
    {
        m_statistics.on_finish_g_layer(static_cast<int64_t>(g_value));

        if (!m_quiet)
        {
            assert(!m_statistics.get_num_expanded_until_g_value().empty());
            self().on_finish_g_layer_impl(g_value, m_statistics.get_num_expanded_until_g_value().back(), m_statistics.get_num_generated_until_g_value().back());
        }
    }

    void on_start_search(const State& start_state) override
    {
        m_statistics = Statistics();

        m_statistics.set_search_start_time_point(std::chrono::high_resolution_clock::now());

        if (!m_quiet)
        {
            self().on_start_search_impl(start_state);
        }
    }

    void on_end_search(uint64_t num_reached_fluent_atoms,
                       uint64_t num_reached_derived_atoms,
                       uint64_t num_states,
                       uint64_t num_nodes,
                       uint64_t num_actions,
                       uint64_t num_axioms) override
    {
        m_statistics.set_search_end_time_point(std::chrono::high_resolution_clock::now());
        m_statistics.set_num_reached_fluent_atoms(num_reached_fluent_atoms);
        m_statistics.set_num_reached_derived_atoms(num_reached_derived_atoms);
        m_statistics.set_num_states(num_states);
        m_statistics.set_num_nodes(num_nodes);
        m_statistics.set_num_actions(num_actions);
        m_statistics.set_num_axioms(num_axioms);

        if (!m_quiet)
        {
            self().on_end_search_impl(num_reached_fluent_atoms, num_reached_derived_atoms, num_states, num_nodes, num_actions, num_axioms);
        }
    }

    void on_finish_iw1_incremental_first_applicability(
        const IW1IncrementalFirstApplicabilityStatistics& iw1_incremental_first_applicability_statistics) override
    {
        m_statistics.set_iw1_incremental_first_applicability_statistics(iw1_incremental_first_applicability_statistics);
    }

    void on_finish_parallel_beam_chunk(size_t chunk_size,
                                       std::chrono::nanoseconds worker_compute_time,
                                       std::chrono::nanoseconds main_thread_merge_time,
                                       std::chrono::nanoseconds main_thread_intern_time,
                                       std::chrono::nanoseconds fluent_slot_time,
                                       std::chrono::nanoseconds numeric_slot_time,
                                       std::chrono::nanoseconds derived_slot_time,
                                       std::chrono::nanoseconds state_lookup_time,
                                       std::chrono::nanoseconds reached_atom_update_time) override
    {
        m_statistics.record_parallel_beam_chunk(chunk_size,
                                               worker_compute_time,
                                               main_thread_merge_time,
                                               main_thread_intern_time,
                                               fluent_slot_time,
                                               numeric_slot_time,
                                               derived_slot_time,
                                               state_lookup_time,
                                               reached_atom_update_time);
    }

    void on_finish_parallel_beam_pipeline(size_t ready_queue_high_water,
                                          size_t in_flight_chunks_high_water,
                                          std::chrono::nanoseconds consumer_stall_time,
                                          std::chrono::nanoseconds producer_stall_time) override
    {
        m_statistics.record_parallel_beam_pipeline(ready_queue_high_water,
                                                   in_flight_chunks_high_water,
                                                   consumer_stall_time,
                                                   producer_stall_time);
    }

    void on_solved(const Plan& plan) override
    {
        if (!m_quiet)
        {
            self().on_solved_impl(plan);
        }
    }

    void on_unsolvable() override
    {
        if (!m_quiet)
        {
            self().on_unsolvable_impl();
        }
    }

    void on_exhausted() override
    {
        if (!m_quiet)
        {
            self().on_exhausted_impl();
        }
    }

    /// @brief Get the statistics.
    const Statistics& get_statistics() const override { return m_statistics; }
    bool is_quiet() const { return m_quiet; }
};

}

#endif
